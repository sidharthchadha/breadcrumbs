""" Tracking a user's restaurant history"""

from abc import abstractproperty

import os
from stat import S_IFBLK

from jinja2 import StrictUndefined

from flask import Flask, render_template, redirect, request, flash, session, jsonify
from flask_debugtoolbar import DebugToolbarExtension

from model import User, Restaurant, Visit, Category, City, RestaurantCategory, Image, Connection , R_to_U , Inventory1 , S_to_I
from model import connect_to_db, db
from friends import is_friends_or_pending, get_friend_requests, get_friends

from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy_searchable import search

from flask_sqlalchemy import SQLAlchemy

from datetime import datetime
from flask import Flask 
from sqlalchemy import delete

from flask import Flask, render_template, request, redirect, url_for, session
from flask_socketio import SocketIO, join_room, leave_room, emit
from flask_session import Session

app = Flask(__name__)
app.debug = True
app.config['SECRET_KEY'] = 'secret'
app.config['SESSION_TYPE'] = 'filesystem'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite31'
#app.config['SECRET_KEY'] = os.environ.get("FLASK_SECRET_KEY", "abcdef")
# app.config['SECRET_KEY'] = 'the random string' 
# app.config['SECRET_KEY'] = 'secret'
# app.config['SECRET_KEY'] = 'secret'
app.config['SESSION_TYPE'] = 'filesystem'
# app.debug = True

Session(app)

socketio = SocketIO(app, manage_session=False)


# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite31'
#app.config['SECRET_KEY'] = os.environ.get("FLASK_SECRET_KEY", "abcdef")
# app.config['SECRET_KEY'] = 'the random string' 
# app.config['SECRET_KEY'] = 'secret'
# app.config['SECRET_KEY'] = 'secret'
# app.config['SESSION_TYPE'] = 'filesystem'
# app.debug = True

db = SQLAlchemy(app)



##############################################################################
# Helper functions


@app.route('/')
def index():
    """Homepage."""

    return render_template("index.html")


@app.route('/main')
def main():
    """Homepage."""
    return render_template("homepage.html")

@app.route("/login", methods=["GET"])
def show_login():
    """Show login form."""

    return render_template("login.html")


@app.route("/login", methods=["POST"])
def login():
    """Log user in if credentials provided are correct."""

    login_email = request.form.get("login_email")
    login_password = request.form.get("login_password")

    try:
        current_user = db.session.query(User).filter(User.email == login_email,
                                                     User.password == login_password).one()
    except NoResultFound:
        flash("The email or password you have entered did not match our records. Please try again.", "danger")
        return redirect("/login")

    # Get current user's friend requests and number of requests to display in badges
    received_friend_requests, sent_friend_requests = get_friend_requests(current_user.user_id)
    num_received_requests = len(received_friend_requests)
    num_sent_requests = len(sent_friend_requests)
    num_total_requests = num_received_requests + num_sent_requests

    # Use a nested dictionary for session["current_user"] to store more than just user_id
    session["current_user"] = {
        "first_name": current_user.first_name,
        "user_id": current_user.user_id,
        "num_received_requests": num_received_requests,
        "num_sent_requests": num_sent_requests,
        "num_total_requests": num_total_requests
    }

    flash("Welcome {}. You have successfully logged in.".format(current_user.first_name), "success")

    return redirect("/users/{}".format(current_user.user_id))


@app.route("/logout")
def logout():
    """Log user out."""

    del session["current_user"]

    flash("Goodbye! You have successfully logged out.", "success")

    return redirect("/")

@app.route("/add_resturant",methods=["POST"])
def add_resturant():
    city_name=request.form.get("city")
    if city_name=='Vancouver':
        city_id=2
    elif city_name=='Sunnyvale':
        city_id=1
    elif city_name=='Delhi':
        city_id=3
    name_of_shop=request.form.get("name")
    phone_no=request.form.get("phone")
    user_id1=request.form.get("userid")
    address=request.form.get("address")
    location_of_shop_latitude=23.4
    location_of_shop_longitude=43.4
     
    res = Restaurant(city_id=city_id,
                         name=name_of_shop,
                         address=address,
                         phone=phone_no,
                         latitude=location_of_shop_latitude,
                         longitude=-location_of_shop_longitude)
                         
    db.session.add(res)
    db.session.commit()
    
    abc= Restaurant.query.filter_by(name=name_of_shop).first()
    print(abc)

    

    obj=R_to_U(resturant_id=abc.restaurant_id,user_id=user_id1)
    db.session.add(obj)
    db.session.commit()
    # mapping of R_to_U model
    
    return redirect("/users/{}".format(user_id1))


@app.route("/add_inventory",methods=["POST"])
def add_inventory():
    # print("\n")
    # print("\n")
    # print("\n")
    resturant_id=request.form.get("shop")
    # print(resturant_id)
    item_name=request.form.get("name")
    description=request.form.get("description")
    price=request.form.get("price")
    no_of_item_in_stock=request.form.get("number")
    image_url=request.form.get("photo")
    available=request.form.get("available")
    
    print(resturant_id,'hello')
    
    
    res = Inventory1(item_name=item_name,
                         item_price=price,
                         item_url=image_url,
                         item_available=available,
                         item_description=description,
                         item_quantity=no_of_item_in_stock)
                         
                         
    db.session.add(res)
    db.session.commit()
    
    
    abc= Inventory1.query.filter_by(item_name=item_name).first()
    #print(abc)

    obj=S_to_I(restaurant_id=resturant_id,item_id=abc.item_id)
    db.session.add(obj)
    db.session.commit()
    # mapping of R_to_U model
    
    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == resturant_id)

    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == resturant_id).one()

    #res_inventory=db.session.query(S_to_I).filter(S_to_I.restaurant_id == restaurant_id)
    res_inventory=S_to_I.query.filter_by(restaurant_id=resturant_id)

    print(res_inventory)

    items=[]

    query = db.session.query(S_to_I).filter(S_to_I.restaurant_id==resturant_id)
    results = query.all()
    #for k in results:
        #print(k.item_id)
    

    for id in results:
        
        #item_detail=Inventory1.query.filter(Inventory1.item_id == id.item_id)
        one_item = db.session.query(Inventory1).filter(Inventory1.item_id==id.item_id)
        results = query.all()
        #print(one_item)
        base=[]
        for j in one_item:
            
            base.append(j.item_name)
            base.append(j.item_price)
            base.append(j.item_url)
            base.append(j.item_description)
            base.append(j.item_available)
            base.append(j.item_quantity)
        items.append(base)  
        #print(base)  

    for x in items:
        print(x)    

   

    return render_template("restaurant_profile.html",
                            
                           restaurant=restaurant,
                           item_list=items
                           )
    # return render_template("restaurant_profile.html",
    #                        restaurant=restaurant)


@app.route("/redirect_resturant",methods=['GET', 'POST'])
def redirect_add_resturant():
    """Show add resturant form."""
    
    return render_template("add_resturant.html"
                    
    )


@app.route("/redirect_inventory",methods=['GET', 'POST'])
def redirect_add_inventory():
    """Show add resturant form."""
    shop_id=request.form.get("shopid")
    #print(shop_id)
    print("\n")
    return render_template("add_inventory.html",shop=shop_id)


@app.route("/redirect_inventory_remove",methods=['GET', 'POST'])
def redirect_inventory_remove():
    """Show add resturant form."""
    shop_id=request.form.get("shopid")
    restaurant_id=shop_id
    k=restaurant_id
    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == restaurant_id).one()

    #res_inventory=db.session.query(S_to_I).filter(S_to_I.restaurant_id == restaurant_id)
    res_inventory=S_to_I.query.filter_by(restaurant_id=restaurant_id)

    print(res_inventory)

    items=[]

    query = db.session.query(S_to_I).filter(S_to_I.restaurant_id==restaurant_id)
    results = query.all()
    #for k in results:
        #print(k.item_id)
    

    for id in results:
        
        #item_detail=Inventory1.query.filter(Inventory1.item_id == id.item_id)
        one_item = db.session.query(Inventory1).filter(Inventory1.item_id==id.item_id)
        results = query.all()
        #print(one_item)
        base=[]
        for j in one_item:
            
            base.append(j.item_name)
            
        items.append(base)  
        #print(base)  

    for x in items:
        print(x)    



    #print(shop_id)
    print("\n")
    return render_template("/remove_inventory.html",
    shop_id=shop_id,
    restaurant=restaurant,
    items=items) 

@app.route("/redirect_inventory_edit",methods=['GET', 'POST'])
def redirect_inventory_edit():
    """Show edit resturant inventory form."""
    shop_id=request.form.get("shopid")
    restaurant_id=shop_id
    k=restaurant_id
    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == restaurant_id).one()

    #res_inventory=db.session.query(S_to_I).filter(S_to_I.restaurant_id == restaurant_id)
    res_inventory=S_to_I.query.filter_by(restaurant_id=restaurant_id)

    print(res_inventory)

    items=[]

    query = db.session.query(S_to_I).filter(S_to_I.restaurant_id==restaurant_id)
    results = query.all()
    #for k in results:
        #print(k.item_id)
    

    for id in results:
        
        #item_detail=Inventory1.query.filter(Inventory1.item_id == id.item_id)
        one_item = db.session.query(Inventory1).filter(Inventory1.item_id==id.item_id)
        results = query.all()
        #print(one_item)
        base=[]
        for j in one_item:
            
            base.append(j.item_name)
            
        items.append(base)  
        #print(base)  

    for x in items:
        print(x)    



    #print(shop_id)
    print("\n")
    return render_template("/edit_inventory.html",
    shop_id=shop_id,
    restaurant=restaurant,
    items=items)     

@app.route("/remove_inventory",methods=["POST"])
def remove_inventory():
    
    resturant_id=request.form.get("shopid")
    
    print(resturant_id)
    item_name=request.form.get("name")
    print(item_name)
    
    print(resturant_id,'hello')

    query = db.session.query(Inventory1).filter(Inventory1.item_name==item_name)
    results=query.all()
    
    list=[]
    for j in results:
        list.append(j.item_id)
        
    for i  in list:
        print(i)    

    a = db.session.query(Inventory1).filter(Inventory1.item_name==item_name)
    resu=a.all()
    db.session.delete(resu[0])

   
    db.session.commit()

    b = db.session.query(S_to_I).filter(S_to_I.item_id==list[0])
    resu1=b.all()
    db.session.delete(resu1[0])

   
    
    db.session.commit()


    # mapping of R_to_U model
    
    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == resturant_id)

    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == resturant_id).one()

    #res_inventory=db.session.query(S_to_I).filter(S_to_I.restaurant_id == restaurant_id)
    
    res_inventory=S_to_I.query.filter_by(restaurant_id=resturant_id)

    # print(res_inventory)

    items=[]

    query = db.session.query(S_to_I).filter(S_to_I.restaurant_id==resturant_id)
    results = query.all()
    #for k in results:
        #print(k.item_id)
    

    for id in results:
        
        #item_detail=Inventory1.query.filter(Inventory1.item_id == id.item_id)
        one_item = db.session.query(Inventory1).filter(Inventory1.item_id==id.item_id)
        results = query.all()
        #print(one_item)
        base=[]
        for j in one_item:
            
            base.append(j.item_name)
            base.append(j.item_price)
            base.append(j.item_url)
            base.append(j.item_description)
            base.append(j.item_available)
            base.append(j.item_quantity)
        items.append(base)  
        #print(base)  

    # for x in items:
        # print(x)    

   

    return render_template("restaurant_profile.html",
                            
                           restaurant=restaurant,
                           item_list=items
                           )

@app.route("/edit_this_item_in_this_shop",methods=["POST"])
def edit_this_item_in_this_shop():
    
    resturant_id=request.form.get("shopid")
    
    print(resturant_id)
    item_name=request.form.get("name")
    print(item_name)
    
    print(resturant_id,'hello')

    query = db.session.query(Inventory1).filter(Inventory1.item_name==item_name)
    results=query.all()
    
    list=[]
    for j in results:
        list.append(j.item_id)
        list.append(j.item_name)
        list.append(j.item_price)
        list.append(j.item_available)
        list.append(j.item_description)
        list.append(j.item_quantity)
        list.append(j.item_url)
        
    for i  in list:
        print(i)    


    # mapping of R_to_U model
    
    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == resturant_id)

    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == resturant_id).one()

    #res_inventory=db.session.query(S_to_I).filter(S_to_I.restaurant_id == restaurant_id)
    
   

    return render_template("edit_item_page.html",
                            
                           restaurant=restaurant,
                           restaurant_id=resturant_id,
                           item=list
                           )


@app.route("/add_and_delete_new_item",methods=["POST"])
def add_and_delete_new_item():
    
    resturant_id=request.form.get("shop")

    extra_copy=resturant_id
    item_id=request.form.get("id")
    print("\n")
    print(resturant_id)
    print("\n")
    item_name=request.form.get("name")
    description=request.form.get("description")
    price=request.form.get("price")
    no_of_item_in_stock=request.form.get("number")
    image_url=request.form.get("photo")
    available=request.form.get("available")
    
    print(resturant_id,'hello')

    resturant_id=request.form.get("shopid")
    
    print(resturant_id)
    item_name=request.form.get("name")
    print(item_name)
    
    print(resturant_id,'hello')

    query = db.session.query(Inventory1).filter(Inventory1.item_name==item_name)
    results=query.all()
    
    list=[]
    for j in results:
        list.append(j.item_id)
        
    for i  in list:
        print(i)    

    a = db.session.query(Inventory1).filter(Inventory1.item_name==item_name)
    resu=a.all()
    db.session.delete(resu[0])

   
    db.session.commit()

    b = db.session.query(S_to_I).filter(S_to_I.item_id==list[0])
    resu1=b.all()
    db.session.delete(resu1[0])

   
    
    db.session.commit()

    print("both deleted\n")



    res = Inventory1(item_name=item_name,
                         item_price=price,
                         item_url=image_url,
                         item_available=available,
                         item_description=description,
                         item_quantity=no_of_item_in_stock)
                         
                         
    db.session.add(res)
    db.session.commit()

    print("inventory added\n")
    

    # abc= Inventory1.query.filter_by(item_name=item_name).first()
    #print(abc)
    print("\n")
    print(extra_copy)
    second_copy=extra_copy
    print("\n")
    obj=S_to_I(restaurant_id=extra_copy,item_id=item_id)
    db.session.add(obj)
    db.session.commit()

    print("second stoi added")
    # mapping of R_to_U model

    print(second_copy)
    print("\n")
    
    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == second_copy)

    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == second_copy).one()

    #res_inventory=db.session.query(S_to_I).filter(S_to_I.restaurant_id == restaurant_id)

    res_inventory=S_to_I.query.filter_by(restaurant_id=second_copy)

    print(res_inventory)

    items=[]

    query = db.session.query(S_to_I).filter(S_to_I.restaurant_id==second_copy)
    results = query.all()

    print("\n")

    for id in results:
        
        #item_detail=Inventory1.query.filter(Inventory1.item_id == id.item_id)
        one_item = db.session.query(Inventory1).filter(Inventory1.item_id==id.item_id)
        results = query.all()
        print(one_item)
        base=[]
        for j in one_item:
            
            base.append(j.item_name)
            base.append(j.item_price)
            base.append(j.item_url)
            base.append(j.item_description)
            base.append(j.item_available)
            base.append(j.item_quantity)
        items.append(base)  
        #print(base)  

    for x in items:
        print(x)    

   

    return render_template("restaurant_profile.html",
                            
                           restaurant=restaurant,
                           item_list=items
                           )

@app.route("/signup", methods=["GET"])
def show_signup():

    """Show signup form."""
    
    return render_template("signup.html")


@app.route("/signup", methods=["POST"])
def signup():

    """Check if user exists in database, otherwise add user to database."""

    print("hello")
    signup_email = request.form.get("signup_email")
    signup_password = request.form.get("signup_password")
    first_name = request.form.get("first_name")
    last_name = request.form.get("last_name")
    city = request.form.get("city")
    print(city)

    city_id = db.session.query(City).filter(City.name == city).one().city_id
    
    print('the city id in the database is ')
    print(city_id)
    try:
        db.session.query(User).filter(User.email == signup_email).one()

    except :
        print('inside except')
        new_user = User(city_id=city_id,
                        email=signup_email,
                        password=signup_password,
                        first_name=first_name,
                        last_name=last_name)
        print(new_user)
        db.session.add(new_user)
        db.session.commit()
        print('commit')
        # Add same info to session for new user as per /login route
        session["current_user"] = {
            "first_name": new_user.first_name,
            "user_id": new_user.user_id,
            "num_received_requests": 0,
            "num_sent_requests": 0,
            "num_total_requests": 0
        }

        flash("You have succesfully signed up for an account, and you are now logged in.", "success")

        return redirect("/users/%s" % new_user.user_id)

    flash("An account already exists with this email address. Please login.", "danger")

    return redirect("/login")


@app.route("/users")
def user_list():
    """Show list of users."""

    users = db.session.query(User).all()

    return render_template("user_list.html",
                           users=users)


@app.route("/users/<int:user_id>")
def user_profile(user_id):
    """Show user profile with map and list of visited restaurants."""

    user = db.session.query(User).filter(User.user_id == user_id).one()

    # Get user's breadcrumbs in descending order
    breadcrumbs = db.session.query(Visit).filter(Visit.user_id == user_id).order_by(Visit.visit_id.desc())

    total_breadcrumbs = len(breadcrumbs.all())
    #recent_breadcrumbs1 = breadcrumbs.limit(5).all()
    #print(type(recent_breadcrumbs1[0]))
    #print(recent_breadcrumbs1)
    shops_ids = db.session.query(R_to_U).filter(R_to_U.user_id== user_id)
    l=[]
    recent_breadcrumbs=None
    #print(shops_ids)
    for shop in shops_ids:  
        #print(shop)
        #print(shop.resturant_id)
        #recent=db.session.query(Restaurant).filter(Restaurant.restaurant_id == shop.restaurant_id).one()
        recent_breadcrumbs = Restaurant.query.filter_by(restaurant_id=shop.resturant_id).first()
        print(recent_breadcrumbs)
        l.append(recent_breadcrumbs)
    #print(recent_breadcrumbs)
    print(type(recent_breadcrumbs))
    total_friends = len(get_friends(user.user_id).all())

    user_a_id = session["current_user"]["user_id"]
    user_b_id = user.user_id

    # Check connection status between user_a and user_b
    friends, pending_request = is_friends_or_pending(user_a_id, user_b_id)

    return render_template("user_profile.html",
                           user=user,
                           total_breadcrumbs=total_breadcrumbs,
                           recent_breadcrumbs=l,
                           total_friends=total_friends,
                           friends=friends,
                           pending_request=pending_request)


@app.route("/users/<int:user_id>/visits.json")
def user_restaurant_visits(user_id):
    """Return info about a user's restaurant visits as JSON."""

    user_visits = db.session.query(Visit).filter(Visit.user_id == user_id).all()

    rest_visits = {}

    for visit in user_visits:
        image_url = visit.restaurant.image_url if visit.restaurant.image_url else "/static/img/restaurant-avatar.png"
        phone = visit.restaurant.phone if visit.restaurant.phone else "Not Available"

        rest_visits[visit.visit_id] = {
            "restaurant": visit.restaurant.name,
            "rest_id": visit.restaurant.restaurant_id,
            "address": visit.restaurant.address,
            "phone": phone,
            "image_url": image_url,
            # Need to convert latitude and longitude to floats
            # Otherwise get a TypeError: Decimal is not JSON serializable
            "latitude": float(visit.restaurant.latitude),
            "longitude": float(visit.restaurant.longitude)
        }

    return jsonify(rest_visits)


@app.route("/add-friend", methods=["POST"])
def add_friend():
    """Send a friend request to another user."""

    user_a_id = session["current_user"]["user_id"]
    user_b_id = request.form.get("user_b_id")

    # Check connection status between user_a and user_b
    is_friends, is_pending = is_friends_or_pending(user_a_id, user_b_id)

    if user_a_id == user_b_id:
        return "You cannot add yourself as a friend."
    elif is_friends:
        return "You are already friends."
    elif is_pending:
        return "Your friend request is pending."
    else:
        requested_connection = Connection(user_a_id=user_a_id,
                                          user_b_id=user_b_id,
                                          status="Requested")
        db.session.add(requested_connection)
        db.session.commit()
        #print "User ID %s has sent a friend request to User ID %s" % (user_a_id, user_b_id)
        return "Request Sent"


@app.route("/friends")
def show_friends_and_requests():
    """Show friend requests and list of all friends"""

    # This returns User objects for current user's friend requests
    received_friend_requests, sent_friend_requests = get_friend_requests(session["current_user"]["user_id"])

    # This returns a query for current user's friends (not User objects), but adding .all() to the end gets list of User objects
    friends = get_friends(session["current_user"]["user_id"]).all()

    return render_template("friends.html",
                           received_friend_requests=received_friend_requests,
                           sent_friend_requests=sent_friend_requests,
                           friends=friends)


@app.route("/friends/search", methods=["GET"])
def search_users():
    """Search for a user by email and return results."""

    # Returns users for current user's friend requests
    received_friend_requests, sent_friend_requests = get_friend_requests(session["current_user"]["user_id"])

    # Returns query for current user's friends (not User objects) so add .all() to the end to get list of User objects
    friends = get_friends(session["current_user"]["user_id"]).all()

    user_input = request.args.get("q")
    print(user_input)
    # Search user's query in users table of db and return all search results
    #search_results = search(db.session.query(User), user_input).all()
    search_results = User.query.filter_by(first_name=user_input).first()
    return render_template("friends_search_results.html",
                           received_friend_requests=received_friend_requests,
                           sent_friend_requests=sent_friend_requests,
                           friends=friends,
                           search_results=[search_results])


@app.route("/restaurants")
def restaurant_list():
    """Show list of restaurants."""

    # Returns all restaurants, sorted alphabetically
    restaurants = db.session.query(Restaurant).order_by(Restaurant.name).all()

    return render_template("restaurant_list.html",
                           restaurants=restaurants)


@app.route("/restaurants/search", methods=["GET"])
def search_restaurants():
    """Search for a restaurant by name or address and return results."""

    user_input = request.args.get("q")

    # Search user's query in restaurant table of db and return all search results
    #search_results = search(db.session.query(Restaurant), user_input).all()

    search_results = db.session.query(Restaurant).filter(Restaurant.name.ilike('%' + user_input  + '%')).all()
    search_results2= db.session.query(Restaurant).filter(Restaurant.address.ilike('%' + user_input  + '%')).all()

    return render_template("restaurants_search_results.html", search_results=search_results,search_results2=search_results2)


@app.route("/restaurants/<int:restaurant_id>")
def restaurant_profile(restaurant_id):
    """Show restaurant information."""

    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == restaurant_id).one()

    # Returns query for current user's friends, not User objects
    friends = get_friends(session["current_user"]["user_id"])

    # Pass friends into this query to filter by restaurant, and join visits table to
    # see which of user's friends have visited this restaurant
    friends_who_visited = friends.filter(Visit.restaurant_id == restaurant_id).join(Visit,
                                                                                    Visit.user_id == Connection.user_b_id).all()

    #res_inventory=S_to_I().query.filter(restaurant_id==S_to_I.restaurant_id).third()
    
    return render_template("restaurant_profile2.html",
                           restaurant=restaurant,
                           friends_who_visited=friends_who_visited)

# for showing shops related to a particular user on his profile 
@app.route("/shops/<int:restaurant_id>")
def shop_list(restaurant_id):
    #print('hello')

    k=restaurant_id

    restaurant = db.session.query(Restaurant).filter(Restaurant.restaurant_id == restaurant_id).one()

    #res_inventory=db.session.query(S_to_I).filter(S_to_I.restaurant_id == restaurant_id)
    res_inventory=S_to_I.query.filter_by(restaurant_id=restaurant_id)

    print(res_inventory)

    items=[]

    query = db.session.query(S_to_I).filter(S_to_I.restaurant_id==restaurant_id)
    results = query.all()
    #for k in results:
        #print(k.item_id)
    

    for id in results:
        
        #item_detail=Inventory1.query.filter(Inventory1.item_id == id.item_id)
        one_item = db.session.query(Inventory1).filter(Inventory1.item_id==id.item_id)
        results = query.all()
        #print(one_item)
        base=[]
        for j in one_item:
            
            base.append(j.item_name)
            base.append(j.item_price)
            base.append(j.item_url)
            base.append(j.item_description)
            base.append(j.item_available)
            base.append(j.item_quantity)
        items.append(base)  
        #print(base)  

    for x in items:
        print(x)    

   

    return render_template("restaurant_profile.html",
                            
                           restaurant=restaurant,
                           item_list=items
                           )

    """Show restaurant information."""
    '''shops_ids = db.session.query(R_to_U).filter(R_to_U.user_id== user_id)
    l=[]
    print(shops_ids)
    for shop in shops_ids:  
        print(shop)
        print(shop.resturant_id)
        #recent=db.session.query(Restaurant).filter(Restaurant.restaurant_id == shop.restaurant_id).one()
        recent = Restaurant.query.filter_by(restaurant_id=shop.resturant_id).first()
        print('hello1')
        print(recent)
        return render_template("user_profile.html",
                           recent=recent)'''
    #print(shops)
    

@app.route("/add-visit", methods=["POST"])
def add_visit():
    """Add restaurant visit to user's restaurant history."""

    restaurant_id = request.form.get("restaurant_id")

    # Checks if user has added this restaurant before
    try:
        db.session.query(Visit).filter(Visit.restaurant_id == restaurant_id,
                                       Visit.user_id == session["current_user"]["user_id"]).one()

    except NoResultFound:
        visit = Visit(user_id=session["current_user"]["user_id"], restaurant_id=restaurant_id)
        db.session.add(visit)
        db.session.commit()

        flash("You just left a breadcrumb for this restaurant.", "success")
        return redirect("/users/%s" % session["current_user"]["user_id"])

    flash("You already left a breadcrumb for this restaurant.", "danger")
    return redirect("/restaurants/%s" % restaurant_id)



@app.route("/accept_req", methods=["POST"])
def accept_req():
    user_a_id = request.form.get("user_a")
    user_b_id = request.form.get("user_b")
    user_id_a=user_a_id
    user_id_b=user_b_id

    print(user_a_id)
    print(user_b_id)
    # print("\n")

    a = db.session.query(Connection).filter(Connection.user_a_id==user_a_id and Connection.user_b_id==user_b_id )
    resu=a.all()
    if(resu):
        db.session.delete(resu[0])

    a = db.session.query(Connection).filter(Connection.user_b_id==user_a_id and Connection.user_a_id==user_b_id )
    resu=a.all()
    if(resu):
        db.session.delete(resu[0])        
   
    db.session.commit()

    
    db.session.commit()

    print("deleted\n")
    k="Accepted"

    user_id=user_id_a

    res = Connection(
                         user_a_id=user_id_a,
                         user_b_id=user_id_b,
                         status=k)
                         
                         
    db.session.add(res)
    db.session.commit()

    print("connection added\n")

    user = db.session.query(User).filter(User.user_id == user_id)

    # Get user's breadcrumbs in descending order
    breadcrumbs = db.session.query(Visit).filter(Visit.user_id == user_id).order_by(Visit.visit_id.desc())

    total_breadcrumbs = len(breadcrumbs.all())
    #recent_breadcrumbs1 = breadcrumbs.limit(5).all()
    #print(type(recent_breadcrumbs1[0]))
    #print(recent_breadcrumbs1)
    shops_ids = db.session.query(R_to_U).filter(R_to_U.user_id== user_a_id)
    l=[]
    recent_breadcrumbs=None
    #print(shops_ids)
    for shop in shops_ids:  
        #print(shop)
        #print(shop.resturant_id)
        #recent=db.session.query(Restaurant).filter(Restaurant.restaurant_id == shop.restaurant_id).one()
        recent_breadcrumbs = Restaurant.query.filter_by(restaurant_id=shop.resturant_id).first()
        l.append(recent_breadcrumbs)
    #print(recent_breadcrumbs)
    print(type(recent_breadcrumbs))
    total_friends = len(get_friends(user.user_id).all())

    user_a_id = session["current_user"]["user_id"]
    user_b_id = user.user_id

    # Check connection status between user_a and user_b
    friends, pending_request = is_friends_or_pending(user_a_id, user_b_id)

    return render_template("user_profile.html",
                           user=user,
                           total_breadcrumbs=total_breadcrumbs,
                           recent_breadcrumbs=l,
                           total_friends=total_friends,
                           friends=friends,
                           pending_request=pending_request)


@app.route("/delete_req", methods=["POST"])
def delete_req():
    user_a_id = request.form.get("user_a")
    user_b_id = request.form.get("user_b")
    user_id_a=user_a_id
    user_id_b=user_b_id

    # print(user_a_id)
    # print(user_b_id)
    # print("\n")

    a = db.session.query(Connection).filter(Connection.user_a_id==user_a_id and Connection.user_b_id==user_b_id )
    resu=a.all()
    if(resu):
        db.session.delete(resu[0])

    a = db.session.query(Connection).filter(Connection.user_b_id==user_a_id and Connection.user_a_id==user_b_id )
    resu=a.all()
    if(resu):
        db.session.delete(resu[0])    

   
    db.session.commit()

    
    db.session.commit()

    print("deleted\n")
    k="Accepted"

    user_id=user_id_a

    
   

    print("commit added\n")

    user = db.session.query(User).filter(User.user_id == user_id).one()

    # Get user's breadcrumbs in descending order
    breadcrumbs = db.session.query(Visit).filter(Visit.user_id == user_id).order_by(Visit.visit_id.desc())

    total_breadcrumbs = len(breadcrumbs.all())
    #recent_breadcrumbs1 = breadcrumbs.limit(5).all()
    #print(type(recent_breadcrumbs1[0]))
    #print(recent_breadcrumbs1)
    shops_ids = db.session.query(R_to_U).filter(R_to_U.user_id== user_a_id)
    l=[]
    recent_breadcrumbs=None
    #print(shops_ids)
    for shop in shops_ids:  
        #print(shop)
        #print(shop.resturant_id)
        #recent=db.session.query(Restaurant).filter(Restaurant.restaurant_id == shop.restaurant_id).one()
        recent_breadcrumbs = Restaurant.query.filter_by(restaurant_id=shop.resturant_id).first()
        l.append(recent_breadcrumbs)
    #print(recent_breadcrumbs)
    print(type(recent_breadcrumbs))
    total_friends = len(get_friends(user.user_id).all())

    user_a_id = session["current_user"]["user_id"]
    user_b_id = user.user_id

    # Check connection status between user_a and user_b
    friends, pending_request = is_friends_or_pending(user_a_id, user_b_id)

    return render_template("user_profile.html",
                           user=user,
                           total_breadcrumbs=total_breadcrumbs,
                           recent_breadcrumbs=l,
                           total_friends=total_friends,
                           friends=friends,
                           pending_request=pending_request)





@app.route("/chat", methods=['GET', 'POST'])
def chat():
    
    username = request.form['username']
    # room = request.form['room']
    res_id=request.form['res_id']

    print(res_id)
    print("\n")
            #Store the data in session
    session['username'] = username
    session['room'] = res_id

    return render_template('chat.html', session = session,res_id=res_id)
    
@socketio.on('join', namespace='/chat')
def join(message):
    room = session.get('room')
    join_room(room)
    emit('status', {'msg':  session.get('username') + ' has entered the room.'}, room=room)


@socketio.on('text', namespace='/chat')
def text(message):
    room = session.get('room')
    emit('message', {'msg': session.get('username') + ' : ' + message['msg']}, room=room)


@socketio.on('left', namespace='/chat')
def left(message):
    room = session.get('room')
    username = session.get('username')
    leave_room(room)
    session.clear()
    emit('status', {'msg': username + ' has left the room.'}, room=room)        
        




@app.route("/error")
def error():
    raise Exception("Error!")


if __name__ == "__main__":
    # Set debug=True here to invoke the DebugToolbarExtension
    # app.run(debug=True,use_reloader=False)
    socketio.run(app)
    
   


